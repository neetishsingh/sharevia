# Sharevia

This is intended to solve server related task